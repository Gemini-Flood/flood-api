<?php

namespace App\Services;

use App\Http\Controllers\Helpers\HelperController;
use Illuminate\Support\Facades\Http;

class WeatherService extends HelperController
{
    protected $apiKey;

    public function __construct()
    {
        $this->apiKey = env('WEATHER_API_KEY');
    }

    public function getWeatherPrediction($lat, $long)
    {
        $url = "https://api.openweathermap.org/data/2.5/weather?lat=".$lat."&lon=".$long."&APPID=".$this->apiKey;

        $response = Http::get($url);

        if($response->failed()) {
            $data = null;
            return $data;
        }

        $data = $response->json();
        return $data;
        // return $response->json();
    }
}
